# Choose A Backend

Use this guide when deciding between `simulation: "cpu"`, `"gpu"`, and `"auto"`.

## Use CPU For Small Gameplay Effects

```ts
const hitSparks: ParticlePreset = {
  simulation: "cpu",
  maxParticles: 64,
  duration: 0.2,
  emission: { bursts: [{ time: 0, count: [20, 36] }] },
};
```

Choose CPU when you need:

- Small particle counts.
- Precise lifecycle callbacks.
- `onParticleDeath`.
- [`collision`](../reference/cpu-backend.md#collision-plane--sphere--box) (`plane`, `sphere`, or `box` primitives).
- Future sub-emitters.
- Gameplay-oriented effects like hit sparks or muzzle flashes.

## Use GPU For Large Visual Effects

```ts
const rain: ParticlePreset = {
  simulation: "gpu",
  maxParticles: 12000,
  duration: 12,
  loop: true,
  prewarm: true,
  autoDispose: false,
  emission: { rateOverTime: 1800 },
};
```

Choose GPU when you need:

- Thousands of particles.
- Ambient visual effects.
- Continuous emission.
- Additive or simple alpha rendering.
- No CPU particle callbacks.

Pass a renderer:

```ts
const wisp = new Wisp({
  scene,
  camera,
  particles: { presets: { rain }, renderer },
});
```

Choose the GPU implementation with `gpu.backend`:

```ts
const rain: ParticlePreset = {
  simulation: "gpu",
  gpu: { backend: "webgl" }, // "auto" by default
};
```

`"auto"` resolves to the renderer-native backend: `WebGLRenderer` uses the WebGL render-target backend, while `WebGPURenderer` requests the experimental WebGPU backend. Import `@tontonius/wisp/webgpu` once before creating WebGPU systems; the core package does not eagerly import Three.js TSL. The WebGPU backend v0 renders TSL billboards with compute-updated motion through a narrow motion readback bridge, but still keeps a CPU mirror for lifecycle bookkeeping and fallback rendering, so keep production presets on `"webgl"` or CPU for now.

## Use Auto For Scalable Defaults

```ts
simulation: "auto",
maxParticles: 5000,
```

`auto` chooses GPU when:

- A compatible renderer is available.
- `maxParticles >= 2048`.

Otherwise it chooses CPU.

## Force CPU Even With GPU Options

```ts
gpu: {
  forceCpuFallback: true,
}
```

This is useful for testing backend differences or temporarily disabling GPU simulation.
